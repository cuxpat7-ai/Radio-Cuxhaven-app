# Radio Cuxhaven – Android App

Native Android-App in Kotlin + Jetpack Compose für den Live-Stream von Radio Cuxhaven.

## Features

- **Live-Stream** via ExoPlayer (Media3) mit Auto-Reconnect
- **ICY-Metadata** → automatische Anzeige von Artist – Titel
- **Cover Art** via iTunes Search API (600×600, Fade-In)
- **Audio-Visualizer** (Android Visualizer API, 14 reaktive Balken)
- **Hintergrund-Wiedergabe** über MediaSessionService + Lockscreen-Steuerung
- **Sendeplan** über externe JSON-API
- **Material 3 Dark Theme** (Spotify-Akzent #1DB954)
- **Bottom Navigation** mit drei Tabs: Radio · Jetzt läuft · Info

## Build

1. Projekt-Ordner in **Android Studio Ladybug (2024.2.1)** oder neuer öffnen.
2. Gradle Sync abwarten.
3. Run > App auf einem Gerät oder Emulator (min. Android 7.0 / API 24).

Über die Kommandozeile:

```bash
./gradlew assembleDebug
```

Das fertige APK liegt unter `app/build/outputs/apk/debug/app-debug.apk`.

Release-Build (signiert):

```bash
./gradlew assembleRelease
```

## Konfiguration

Alle URLs und Konstanten sind zentral in einer Datei:

`app/src/main/java/com/radiocuxhaven/app/util/Constants.kt`

| Konstante      | Default                                                       |
|----------------|---------------------------------------------------------------|
| STREAM_URL     | `https://www.racux.de/listen/radiocuxhaven/radio.mp3`         |
| SCHEDULE_URL   | `https://radio-cuxhaven.com/api/sendeplan.json` *(anpassen)*  |
| URL_PRIVACY    | `https://radio-cuxhaven.com/page/datenschutz`                 |
| URL_IMPRINT    | `https://radio-cuxhaven.com/page/impressum`                   |

### Sendeplan-API-Format

Das ScheduleRepository akzeptiert **zwei** Formate – nimm das passendere:

**Variante A** – nacktes Array:

```json
[
  { "time": "06:00", "title": "Morgenwelle", "moderator": "Jan" },
  { "time": "10:00", "title": "Küstenmix",   "moderator": "Tina" }
]
```

**Variante B** – mit Hülle:

```json
{
  "items": [
    { "time": "06:00", "title": "Morgenwelle", "moderator": "Jan",
      "description": "Wach werden mit der Küste", "image": "https://..." }
  ]
}
```

Felder: `time`, `title`, `moderator?`, `description?`, `image?`, `day?` – alle optional außer `time` + `title`.

## Architektur

```
com.radiocuxhaven.app
├── MainActivity                  – Compose Host + Permission-Handling
├── RadioCuxhavenApplication      – DI-Light (lazy Repos), NotificationChannel
├── navigation/
│   └── AppNavigation             – Scaffold + Bottom Nav + NavHost
├── player/
│   ├── PlayerManager             – Singleton: ExoPlayer + ICY + Reconnect
│   ├── PlayerState               – sealed interface
│   └── RadioPlayerService        – MediaSessionService (Foreground)
├── data/
│   ├── api/HttpClientProvider    – OkHttp Singleton
│   ├── repository/
│   │   ├── RadioRepository       – iTunes Cover-Lookup
│   │   └── ScheduleRepository    – Sendeplan-JSON
│   └── model/                    – TrackInfo, ScheduleItem, iTunes-Modelle
└── ui/
    ├── theme/                    – Material3 Dark Theme + Typo
    ├── components/               – PlayPauseButton, LiveBadge, CoverArt,
    │                               AudioVisualizer
    └── screens/
        ├── radio/                – RadioScreen + ViewModel
        ├── nowplaying/           – NowPlayingScreen (teilt RadioViewModel)
        └── info/                 – InfoScreen + InfoViewModel
```

## Permissions

- `INTERNET`, `ACCESS_NETWORK_STATE` – Streaming
- `FOREGROUND_SERVICE` + `FOREGROUND_SERVICE_MEDIA_PLAYBACK` – Hintergrund-Wiedergabe
- `POST_NOTIFICATIONS` – Lockscreen-Notification (Android 13+)
- `RECORD_AUDIO` – Audio-Visualizer (System-Visualizer fragt explizit, falls verweigert → stiller Fallback)
- `WAKE_LOCK` – ExoPlayer-intern

## Logo / Branding ersetzen

Aktuell ist ein generischer „RC"-Vector als Platzhalter eingebaut:
`app/src/main/res/drawable/ic_station_logo.xml`

Echtes Logo:

1. Vector-Drawable austauschen (XML), **oder**
2. In Android Studio: Rechtsklick auf `res` > New > Image Asset > Image Asset Studio, Pfad „Launcher Icons (Adaptive and Legacy)" – die Bitmap-Dateien unter `mipmap-*dpi/` werden dabei überschrieben.

## Lizenzen / Drittbibliotheken

- AndroidX, Jetpack Compose, Media3 (Apache 2.0)
- OkHttp (Apache 2.0)
- Coil (Apache 2.0)
- Kotlinx Serialization / Coroutines (Apache 2.0)

## Hinweise für Patrick

- **iTunes-Cover-Lookup** ist best-effort: Wenn ICY-Metadata kein „Artist – Title" liefert oder iTunes nichts findet, wird das Senderlogo angezeigt. Keine Fehler-Toast-Spam.
- **Reconnect-Backoff**: 3 s × Versuche (max. 4 ×), bis zu 10 Wiederholungen, dann „Verbindung verloren" – Tap aufs Pause/Play startet manuell neu.
- **MediaSession**: Lockscreen + Bluetooth-Headset-Tasten (Pause/Play) funktionieren automatisch.
- **DSGVO**: Keine Tracker, keine Analytics, kein externes CDN. Coil-Loader hält Bilder nur im Memory-Cache.

---

**Version**: 1.0.0 · **minSdk**: 24 · **targetSdk**: 35 · **Kotlin**: 2.0.21
