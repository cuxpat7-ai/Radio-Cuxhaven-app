# APK vom Handy bauen – ohne PC

Du brauchst nur:
- GitHub-Account (kostenlos, github.com)
- Dieses Projekt-ZIP
- Optional: GitHub-App fürs Handy (iOS / Android)

## Variante A: Web-Browser (am Handy oder Tablet)

### 1. Repo anlegen

1. github.com öffnen, einloggen
2. Oben rechts „+" → **New repository**
3. Name: `radio-cuxhaven-android` (oder beliebig)
4. Sichtbarkeit: **Private** empfohlen
5. „Initialize with README" *nicht* anhaken
6. **Create repository**

### 2. Files hochladen

1. Auf der leeren Repo-Seite: Link **„uploading an existing file"** antippen
2. Im Datei-Picker: das entpackte `RadioCuxhaven/`-Verzeichnis hochladen (Drag&Drop funktioniert im Browser, Desktop-Modus erleichtert das)
3. Commit-Message reicht „initial"
4. **Commit changes** drücken

> Tipp: Wenn das Hochladen einzelner Files zu mühsam wird, nutze die GitHub-Mobile-App (Schritt B).

### 3. Build läuft automatisch

1. Nach dem Push geht oben der Reiter **„Actions"** an (gelber Punkt → Build läuft)
2. Bauzeit: 5–8 Minuten beim ersten Mal
3. Wenn der Punkt grün ist: Auf den Workflow-Run tippen
4. Unten unter **„Artifacts"** findest du:
   - `RadioCuxhaven-debug-apk` (zum Installieren)
   - `RadioCuxhaven-release-unsigned-apk` (für Play Store – muss noch signiert werden)

### 4. APK installieren

1. Artifact-ZIP runterladen
2. Mit einem File-Manager (z. B. „Files by Google") entpacken
3. APK antippen → „Aus dieser Quelle erlauben" erlauben → installieren

## Variante B: GitHub Mobile App

1. App „GitHub" aus dem Play Store installieren
2. Einloggen
3. Repo wie oben anlegen (geht auch in der App)
4. Code-Upload per Web-Browser (App selbst kann keine Massen-Uploads)
5. **Build-Status, APK-Download, Workflow-Restart** alles in der App möglich

## Variante C: Direkt aus Termux (für Power-User)

Wenn du Termux installiert hast:

```bash
pkg install git gh
gh auth login
git clone https://github.com/USERNAME/radio-cuxhaven-android.git
cd radio-cuxhaven-android
# Files reinkopieren, hinzufügen, pushen
git add .
git commit -m "initial"
git push
```

## Was tun bei Build-Fehler?

1. Auf Actions tippen → Roten Run anklicken
2. Im Log nach `FAILURE:` oder `error:` suchen
3. Häufige Ursachen:
   - **Falscher Pfad in `gradlew`** → die Datei muss im Repo-Root liegen, nicht im `RadioCuxhaven/`-Unterordner
   - **`gradle-wrapper.jar` fehlt** → muss in `gradle/wrapper/` liegen (ist im ZIP enthalten)
   - **Lint-Errors** → in `app/build.gradle.kts` `lint { abortOnError = false }` ergänzen

## Release-APK signieren (optional)

Die `release-unsigned-apk` läßt sich nicht installieren. Zum Signieren:

1. Lokal einmalig (oder in Termux) einen Keystore erstellen:
   ```bash
   keytool -genkey -v -keystore radiocuxhaven.jks \
     -keyalg RSA -keysize 2048 -validity 10000 \
     -alias radiocuxhaven
   ```
2. Keystore als Base64 nach GitHub Secrets hochladen (Repo → Settings → Secrets → Actions)
3. Im Workflow Signing-Step ergänzen – Anleitung dazu gerne separat, sobald du das brauchst.

Für die ersten Tests reicht die **Debug-APK** – die ist signiert und sofort installierbar.
