package com.radiocuxhaven.app.ui.components

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.radiocuxhaven.app.R

@Composable
fun CoverArt(
    coverUrl: String?,
    modifier: Modifier = Modifier,
    size: Dp = 280.dp,
    corner: Dp = 16.dp
) {
    Box(
        modifier = modifier
            .size(size)
            .clip(RoundedCornerShape(corner))
            .background(MaterialTheme.colorScheme.surfaceVariant),
        contentAlignment = Alignment.Center
    ) {
        AnimatedContent(
            targetState = coverUrl,
            transitionSpec = {
                (fadeIn(tween(450)) + scaleIn(tween(450), initialScale = 0.92f))
                    .togetherWith(fadeOut(tween(220)))
            },
            label = "cover-swap"
        ) { url ->
            if (url.isNullOrBlank()) {
                FallbackLogo()
            } else {
                AsyncImage(
                    model = ImageRequest.Builder(androidx.compose.ui.platform.LocalContext.current)
                        .data(url)
                        .crossfade(true)
                        .build(),
                    contentDescription = "Cover",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize(),
                    error = painterResource(id = R.drawable.ic_station_logo),
                    fallback = painterResource(id = R.drawable.ic_station_logo)
                )
            }
        }
    }
}

@Composable
private fun FallbackLogo() {
    Image(
        painter = painterResource(id = R.drawable.ic_station_logo),
        contentDescription = "Radio Cuxhaven Logo",
        contentScale = ContentScale.Fit,
        modifier = Modifier
            .fillMaxSize()
    )
}
