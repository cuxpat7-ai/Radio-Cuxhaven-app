package com.radiocuxhaven.app.player

import android.content.Context
import androidx.annotation.OptIn
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Metadata
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.extractor.metadata.icy.IcyHeaders
import androidx.media3.extractor.metadata.icy.IcyInfo
import com.radiocuxhaven.app.data.model.TrackInfo
import com.radiocuxhaven.app.util.Constants
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

/**
 * Singleton-Wrapper um den ExoPlayer.
 * - Hält den State als Flows (Player-State, TrackInfo, Audio-Session-ID)
 * - Liest ICY-Metadaten und schickt sie nach außen
 * - Macht Auto-Reconnect bei Stream-Fehlern (Backoff)
 */
@OptIn(UnstableApi::class)
class PlayerManager private constructor(context: Context) {

    private val appContext = context.applicationContext
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    private val _playerState = MutableStateFlow<PlayerState>(PlayerState.Idle)
    val playerState: StateFlow<PlayerState> = _playerState.asStateFlow()

    private val _trackInfo = MutableStateFlow(TrackInfo.LIVE_FALLBACK)
    val trackInfo: StateFlow<TrackInfo> = _trackInfo.asStateFlow()

    private val _audioSessionId = MutableStateFlow(0)
    val audioSessionId: StateFlow<Int> = _audioSessionId.asStateFlow()

    private var reconnectJob: Job? = null
    private var reconnectAttempts = 0

    /** Lazy-initialisierter ExoPlayer (Main-Thread-only). */
    val exoPlayer: ExoPlayer by lazy { buildPlayer() }

    private fun buildPlayer(): ExoPlayer {
        val httpFactory = DefaultHttpDataSource.Factory()
            .setUserAgent(Constants.USER_AGENT)
            .setAllowCrossProtocolRedirects(true)
            .setDefaultRequestProperties(mapOf(Constants.ICY_METADATA_HEADER to "1"))
            .setConnectTimeoutMs(15_000)
            .setReadTimeoutMs(20_000)

        val mediaSourceFactory = DefaultMediaSourceFactory(appContext)
            .setDataSourceFactory(httpFactory)

        return ExoPlayer.Builder(appContext)
            .setMediaSourceFactory(mediaSourceFactory)
            .setHandleAudioBecomingNoisy(true)
            .build()
            .apply {
                setMediaItem(buildMediaItem())
                _audioSessionId.value = audioSessionId
                addListener(playerListener)
            }
    }

    private fun buildMediaItem(): MediaItem = MediaItem.Builder()
        .setUri(Constants.STREAM_URL)
        .setLiveConfiguration(
            MediaItem.LiveConfiguration.Builder()
                .setMaxPlaybackSpeed(1.02f)
                .build()
        )
        .setMediaMetadata(
            MediaMetadata.Builder()
                .setTitle(Constants.STATION_NAME)
                .setArtist(Constants.STATION_TAGLINE)
                .setIsBrowsable(false)
                .setIsPlayable(true)
                .build()
        )
        .build()

    private val playerListener = object : Player.Listener {

        override fun onPlaybackStateChanged(playbackState: Int) {
            when (playbackState) {
                Player.STATE_BUFFERING -> _playerState.value = PlayerState.Buffering
                Player.STATE_READY -> {
                    reconnectAttempts = 0
                    _playerState.value =
                        if (exoPlayer.playWhenReady) PlayerState.Playing else PlayerState.Paused
                }
                Player.STATE_ENDED -> {
                    // Live-Stream sollte nie enden – als Fehler behandeln + reconnect
                    scheduleReconnect("Stream beendet")
                }
                Player.STATE_IDLE -> _playerState.value = PlayerState.Idle
            }
        }

        override fun onIsPlayingChanged(isPlaying: Boolean) {
            if (isPlaying) {
                _playerState.value = PlayerState.Playing
            } else if (exoPlayer.playbackState == Player.STATE_READY) {
                _playerState.value = PlayerState.Paused
            }
        }

        override fun onPlayerError(error: PlaybackException) {
            scheduleReconnect(error.message ?: "Stream-Fehler")
        }

        override fun onMetadata(metadata: Metadata) {
            for (i in 0 until metadata.length()) {
                when (val entry = metadata.get(i)) {
                    is IcyInfo -> entry.title?.takeIf { it.isNotBlank() }?.let { handleIcyTitle(it) }
                    is IcyHeaders -> {
                        // Header-Infos derzeit nicht aktiv genutzt
                    }
                }
            }
        }

        override fun onAudioSessionIdChanged(sessionId: Int) {
            _audioSessionId.value = sessionId
        }
    }

    private fun handleIcyTitle(raw: String) {
        val info = TrackInfo.fromIcyTitle(raw)
        if (info.raw != _trackInfo.value.raw) {
            _trackInfo.value = info
        }
    }

    /** Externes Update der TrackInfo (z. B. nachdem Cover geladen wurde). */
    fun updateTrackInfo(updated: TrackInfo) {
        _trackInfo.value = updated
    }

    fun play() {
        reconnectJob?.cancel()
        reconnectAttempts = 0
        // Foreground-Service starten, damit Wiedergabe im Hintergrund läuft
        runCatching {
            val intent = android.content.Intent(appContext, RadioPlayerService::class.java)
            androidx.core.content.ContextCompat.startForegroundService(appContext, intent)
        }
        val p = exoPlayer
        if (p.playbackState == Player.STATE_IDLE || p.playbackState == Player.STATE_ENDED) {
            p.setMediaItem(buildMediaItem())
            p.prepare()
        }
        p.playWhenReady = true
    }

    fun pause() {
        reconnectJob?.cancel()
        exoPlayer.playWhenReady = false
    }

    fun toggle() {
        if (exoPlayer.isPlaying) pause() else play()
    }

    fun stop() {
        reconnectJob?.cancel()
        exoPlayer.stop()
        _playerState.value = PlayerState.Idle
    }

    private fun scheduleReconnect(reason: String) {
        if (reconnectAttempts >= Constants.MAX_RECONNECT_ATTEMPTS) {
            _playerState.value = PlayerState.Error("Verbindung verloren: $reason")
            return
        }
        reconnectJob?.cancel()
        reconnectJob = scope.launch {
            reconnectAttempts++
            _playerState.value = PlayerState.Error("Verbindung verloren – versuche erneut ($reconnectAttempts)")
            delay(Constants.RECONNECT_DELAY_MS * minOf(reconnectAttempts, 4))
            val p = exoPlayer
            p.setMediaItem(buildMediaItem())
            p.prepare()
            p.playWhenReady = true
        }
    }

    fun release() {
        reconnectJob?.cancel()
        exoPlayer.removeListener(playerListener)
        exoPlayer.release()
        instanceRef = null
    }

    companion object {
        @Volatile
        private var instanceRef: PlayerManager? = null

        fun get(context: Context): PlayerManager =
            instanceRef ?: synchronized(this) {
                instanceRef ?: PlayerManager(context).also { instanceRef = it }
            }
    }
}
