package com.radiocuxhaven.app.data.model

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
data class ScheduleItem(
    val time: String = "",
    val title: String = "",
    val moderator: String? = null,
    val description: String? = null,
    @SerialName("image") val imageUrl: String? = null,
    val day: String? = null
)

@Serializable
data class ScheduleResponse(
    val items: List<ScheduleItem> = emptyList()
)
