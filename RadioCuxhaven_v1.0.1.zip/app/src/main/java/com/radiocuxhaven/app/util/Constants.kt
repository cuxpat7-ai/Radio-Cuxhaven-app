package com.radiocuxhaven.app.util

object Constants {

    // Stream
    const val STREAM_URL = "https://www.racux.de/listen/radiocuxhaven/radio.mp3"
    const val STATION_NAME = "Radio Cuxhaven"
    const val STATION_TAGLINE = "Dein Sender für die Nordseeküste"

    // Sendeplan / News JSON-Endpoint (anpassen falls anderer Pfad)
    const val SCHEDULE_URL = "https://radio-cuxhaven.com/api/sendeplan.json"

    // iTunes Search API für Cover Art
    const val ITUNES_SEARCH_URL = "https://itunes.apple.com/search"

    // Info-Links
    const val URL_PRIVACY = "https://radio-cuxhaven.com/page/datenschutz"
    const val URL_IMPRINT = "https://radio-cuxhaven.com/page/impressum"
    const val URL_WEBSITE = "https://radio-cuxhaven.com"

    // Player
    const val RECONNECT_DELAY_MS = 3_000L
    const val MAX_RECONNECT_ATTEMPTS = 10

    // Notification
    const val NOTIFICATION_CHANNEL_ID = "radio_cuxhaven_playback"
    const val NOTIFICATION_ID = 1001

    // Network
    const val USER_AGENT = "RadioCuxhavenApp/1.0 (Android)"
    const val ICY_METADATA_HEADER = "Icy-MetaData"
}
