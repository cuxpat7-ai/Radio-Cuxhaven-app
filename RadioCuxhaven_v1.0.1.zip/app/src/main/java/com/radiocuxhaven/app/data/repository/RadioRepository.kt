package com.radiocuxhaven.app.data.repository

import com.radiocuxhaven.app.data.model.ITunesSearchResponse
import com.radiocuxhaven.app.util.Constants
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import okhttp3.HttpUrl.Companion.toHttpUrl
import okhttp3.OkHttpClient
import okhttp3.Request

class RadioRepository(private val httpClient: OkHttpClient) {

    private val json = Json {
        ignoreUnknownKeys = true
        isLenient = true
    }

    /**
     * Sucht Cover-Artwork via iTunes Search API.
     * Gibt 600x600 Artwork-URL zurück oder null.
     */
    suspend fun fetchCoverArt(artist: String, title: String): String? = withContext(Dispatchers.IO) {
        if (artist.isBlank() && title.isBlank()) return@withContext null

        val term = "$artist $title".trim()
        val url = Constants.ITUNES_SEARCH_URL.toHttpUrl()
            .newBuilder()
            .addQueryParameter("term", term)
            .addQueryParameter("entity", "song")
            .addQueryParameter("limit", "1")
            .build()

        runCatching {
            val request = Request.Builder().url(url).get().build()
            httpClient.newCall(request).execute().use { response ->
                if (!response.isSuccessful) return@use null
                val body = response.body?.string() ?: return@use null
                val parsed = json.decodeFromString<ITunesSearchResponse>(body)
                parsed.results.firstOrNull()?.highResArtwork()
            }
        }.getOrNull()
    }
}
