package com.radiocuxhaven.app.player

sealed interface PlayerState {
    data object Idle : PlayerState
    data object Buffering : PlayerState
    data object Playing : PlayerState
    data object Paused : PlayerState
    data class Error(val message: String) : PlayerState
}
