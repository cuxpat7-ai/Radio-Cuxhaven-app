package com.radiocuxhaven.app.data.model

data class TrackInfo(
    val artist: String,
    val title: String,
    val coverUrl: String? = null,
    val raw: String = ""
) {
    val displayLine: String
        get() = if (artist.isNotBlank() && title.isNotBlank()) "$artist – $title"
                else if (title.isNotBlank()) title
                else "Radio Cuxhaven Live"

    companion object {
        val LIVE_FALLBACK = TrackInfo(
            artist = "",
            title = "Radio Cuxhaven Live",
            coverUrl = null,
            raw = ""
        )

        /**
         * Parst ICY-StreamTitle wie "Artist - Title" oder "Title".
         */
        fun fromIcyTitle(raw: String): TrackInfo {
            val cleaned = raw.trim().removePrefix("StreamTitle=").trim('\'', ' ', ';')
            if (cleaned.isBlank()) return LIVE_FALLBACK
            val parts = cleaned.split(" - ", limit = 2)
            return if (parts.size == 2) {
                TrackInfo(
                    artist = parts[0].trim(),
                    title = parts[1].trim(),
                    raw = cleaned
                )
            } else {
                TrackInfo(artist = "", title = cleaned, raw = cleaned)
            }
        }
    }
}
