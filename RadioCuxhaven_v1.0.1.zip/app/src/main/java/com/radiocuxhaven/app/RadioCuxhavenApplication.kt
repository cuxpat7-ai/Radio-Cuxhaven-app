package com.radiocuxhaven.app

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import com.radiocuxhaven.app.data.api.HttpClientProvider
import com.radiocuxhaven.app.data.repository.RadioRepository
import com.radiocuxhaven.app.data.repository.ScheduleRepository
import com.radiocuxhaven.app.util.Constants

class RadioCuxhavenApplication : Application() {

    val radioRepository: RadioRepository by lazy {
        RadioRepository(HttpClientProvider.client)
    }

    val scheduleRepository: ScheduleRepository by lazy {
        ScheduleRepository(HttpClientProvider.client)
    }

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                Constants.NOTIFICATION_CHANNEL_ID,
                "Radio-Wiedergabe",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Steuerung der Live-Wiedergabe"
                setShowBadge(false)
                enableVibration(false)
            }
            val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            manager.createNotificationChannel(channel)
        }
    }
}
