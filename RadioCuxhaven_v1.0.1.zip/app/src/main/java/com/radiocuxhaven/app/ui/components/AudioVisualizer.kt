package com.radiocuxhaven.app.ui.components

import android.Manifest
import android.content.pm.PackageManager
import android.media.audiofx.Visualizer
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import kotlin.math.abs
import kotlin.math.max

private const val BAR_COUNT = 14

/**
 * Audio Visualizer – fängt Waveform vom System ab und rendert Balken.
 * Visualizer braucht RECORD_AUDIO. Bei verweigerter Permission: stille Bars.
 */
@Composable
fun AudioVisualizer(
    audioSessionId: Int,
    isPlaying: Boolean,
    modifier: Modifier = Modifier,
    height: Dp = 90.dp
) {
    val context = LocalContext.current
    var hasPermission by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO)
                == PackageManager.PERMISSION_GRANTED
        )
    }

    val permLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted -> hasPermission = granted }

    LaunchedEffect(isPlaying, hasPermission) {
        if (isPlaying && !hasPermission) {
            permLauncher.launch(Manifest.permission.RECORD_AUDIO)
        }
    }

    val levels = remember { FloatArray(BAR_COUNT) { 0.1f } }
    var tick by remember { mutableStateOf(0) }
    val barColor: Color = MaterialTheme.colorScheme.primary

    DisposableEffect(audioSessionId, hasPermission, isPlaying) {
        if (audioSessionId == 0 || !hasPermission || !isPlaying) {
            return@DisposableEffect onDispose { }
        }

        val visualizer: Visualizer? = try {
            Visualizer(audioSessionId).apply {
                val range = Visualizer.getCaptureSizeRange()
                captureSize = 256.coerceIn(range[0], range[1])
                setDataCaptureListener(
                    object : Visualizer.OnDataCaptureListener {
                        override fun onWaveFormDataCapture(
                            v: Visualizer?,
                            waveform: ByteArray?,
                            samplingRate: Int
                        ) {
                            waveform ?: return
                            updateBars(waveform, levels)
                            tick++
                        }

                        override fun onFftDataCapture(
                            v: Visualizer?,
                            fft: ByteArray?,
                            samplingRate: Int
                        ) { /* unused */ }
                    },
                    Visualizer.getMaxCaptureRate() / 2,
                    true,
                    false
                )
                enabled = true
            }
        } catch (t: Throwable) {
            null
        }

        onDispose {
            runCatching {
                visualizer?.enabled = false
                visualizer?.release()
            }
        }
    }

    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(height)
            .clip(RoundedCornerShape(12.dp))
    ) {
        @Suppress("UNUSED_EXPRESSION") tick // erzwingt Recomposition bei neuen Samples

        Canvas(modifier = Modifier.fillMaxWidth().height(height)) {
            val totalWidth = size.width
            val gap = 6.dp.toPx()
            val barWidth = max(2f, (totalWidth - gap * (BAR_COUNT - 1)) / BAR_COUNT)
            val maxBarHeight = size.height
            val centerY = maxBarHeight / 2f

            for (i in 0 until BAR_COUNT) {
                val level = levels[i].coerceIn(0.05f, 1f)
                val barHeight = maxBarHeight * level
                val x = i * (barWidth + gap)
                drawRoundRect(
                    color = barColor,
                    topLeft = Offset(x, centerY - barHeight / 2f),
                    size = Size(barWidth, barHeight),
                    cornerRadius = CornerRadius(barWidth / 2f, barWidth / 2f)
                )
            }
        }
    }
}

private fun updateBars(waveform: ByteArray, levels: FloatArray) {
    val chunk = waveform.size / levels.size
    if (chunk <= 0) return
    for (i in levels.indices) {
        var sum = 0
        val start = i * chunk
        val end = (start + chunk).coerceAtMost(waveform.size)
        for (j in start until end) {
            sum += abs(waveform[j].toInt() - 128)
        }
        val avg = sum.toFloat() / (end - start)
        val norm = (avg / 128f).coerceIn(0f, 1f)
        // einfache Glättung
        levels[i] = levels[i] * 0.55f + norm * 0.45f
    }
}
