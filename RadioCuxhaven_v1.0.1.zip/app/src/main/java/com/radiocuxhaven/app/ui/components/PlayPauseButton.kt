package com.radiocuxhaven.app.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.radiocuxhaven.app.player.PlayerState

@Composable
fun PlayPauseButton(
    state: PlayerState,
    onToggle: () -> Unit,
    size: Dp = 92.dp
) {
    val scale by animateFloatAsState(
        targetValue = if (state is PlayerState.Playing) 1f else 0.96f,
        animationSpec = tween(220),
        label = "play-scale"
    )

    Box(
        modifier = Modifier
            .size(size)
            .scale(scale)
            .background(MaterialTheme.colorScheme.primary, CircleShape)
            .clickable(onClick = onToggle),
        contentAlignment = Alignment.Center
    ) {
        when (state) {
            PlayerState.Buffering -> CircularProgressIndicator(
                color = MaterialTheme.colorScheme.onPrimary,
                strokeWidth = 3.dp,
                modifier = Modifier.size(size * 0.42f)
            )
            else -> {
                val icon: ImageVector = if (state is PlayerState.Playing) {
                    androidx.compose.material.icons.Icons.Filled.Pause
                } else {
                    androidx.compose.material.icons.Icons.Filled.PlayArrow
                }
                Icon(
                    imageVector = icon,
                    contentDescription = if (state is PlayerState.Playing) "Pause" else "Wiedergabe",
                    tint = MaterialTheme.colorScheme.onPrimary,
                    modifier = Modifier.size(size * 0.5f)
                )
            }
        }
    }
}
