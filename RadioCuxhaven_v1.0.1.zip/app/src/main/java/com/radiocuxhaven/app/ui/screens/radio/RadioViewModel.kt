package com.radiocuxhaven.app.ui.screens.radio

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.radiocuxhaven.app.RadioCuxhavenApplication
import com.radiocuxhaven.app.data.model.TrackInfo
import com.radiocuxhaven.app.player.PlayerManager
import com.radiocuxhaven.app.player.PlayerState
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.launchIn
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.onEach
import kotlinx.coroutines.flow.stateIn

class RadioViewModel(app: Application) : AndroidViewModel(app) {

    private val application = app as RadioCuxhavenApplication
    private val player = PlayerManager.get(app)

    val playerState: StateFlow<PlayerState> = player.playerState
    val trackInfo: StateFlow<TrackInfo> = player.trackInfo
    val audioSessionId: StateFlow<Int> = player.audioSessionId

    val isPlaying: StateFlow<Boolean> = player.playerState
        .map { it is PlayerState.Playing }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), false)

    init {
        // Bei jedem Trackwechsel Cover nachladen
        player.trackInfo
            .distinctUntilChanged { a, b -> a.raw == b.raw }
            .onEach { info ->
                if (info.artist.isBlank() && info.title.isBlank()) return@onEach
                if (info.title == TrackInfo.LIVE_FALLBACK.title) return@onEach
                val cover = application.radioRepository.fetchCoverArt(info.artist, info.title)
                if (cover != null && cover != info.coverUrl) {
                    player.updateTrackInfo(info.copy(coverUrl = cover))
                }
            }
            .launchIn(viewModelScope)
    }

    fun togglePlayback() = player.toggle()
    fun play() = player.play()
    fun pause() = player.pause()
}
