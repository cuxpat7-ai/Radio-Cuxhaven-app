package com.radiocuxhaven.app.ui.theme

import androidx.compose.ui.graphics.Color

// Brand
val AccentGreen = Color(0xFF1DB954)
val AccentGreenDark = Color(0xFF169C46)

// Dark Mode Surfaces (Spotify-ish)
val BackgroundBlack = Color(0xFF0A0A0A)
val SurfaceDark = Color(0xFF121212)
val SurfaceElev1 = Color(0xFF1A1A1A)
val SurfaceElev2 = Color(0xFF222222)
val OutlineDim = Color(0xFF2A2A2A)

// Text
val TextPrimary = Color(0xFFEDEDED)
val TextSecondary = Color(0xFFB3B3B3)
val TextTertiary = Color(0xFF7A7A7A)

// Status
val LiveRed = Color(0xFFE53935)
