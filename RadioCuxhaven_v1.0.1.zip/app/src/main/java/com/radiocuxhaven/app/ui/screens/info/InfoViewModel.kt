package com.radiocuxhaven.app.ui.screens.info

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.radiocuxhaven.app.RadioCuxhavenApplication
import com.radiocuxhaven.app.data.model.ScheduleItem
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

sealed interface ScheduleUiState {
    data object Loading : ScheduleUiState
    data class Ready(val items: List<ScheduleItem>) : ScheduleUiState
    data class Failed(val message: String) : ScheduleUiState
    data object Empty : ScheduleUiState
}

class InfoViewModel(app: Application) : AndroidViewModel(app) {

    private val application = app as RadioCuxhavenApplication

    private val _schedule = MutableStateFlow<ScheduleUiState>(ScheduleUiState.Loading)
    val schedule: StateFlow<ScheduleUiState> = _schedule.asStateFlow()

    init { reload() }

    fun reload() {
        _schedule.value = ScheduleUiState.Loading
        viewModelScope.launch {
            val result = application.scheduleRepository.fetchSchedule()
            _schedule.value = result.fold(
                onSuccess = { list ->
                    if (list.isEmpty()) ScheduleUiState.Empty
                    else ScheduleUiState.Ready(list)
                },
                onFailure = { ScheduleUiState.Failed(it.message ?: "Unbekannter Fehler") }
            )
        }
    }
}
