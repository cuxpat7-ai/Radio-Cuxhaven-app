package com.radiocuxhaven.app.data.model

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
data class ITunesSearchResponse(
    val resultCount: Int = 0,
    val results: List<ITunesResult> = emptyList()
)

@Serializable
data class ITunesResult(
    val artistName: String? = null,
    val trackName: String? = null,
    val collectionName: String? = null,
    @SerialName("artworkUrl100") val artworkUrl100: String? = null,
    @SerialName("artworkUrl60") val artworkUrl60: String? = null
) {
    /** Upscale 100x100 → 600x600 (iTunes-Konvention). */
    fun highResArtwork(): String? {
        val base = artworkUrl100 ?: artworkUrl60 ?: return null
        return base.replace("100x100bb", "600x600bb")
            .replace("60x60bb", "600x600bb")
    }
}
