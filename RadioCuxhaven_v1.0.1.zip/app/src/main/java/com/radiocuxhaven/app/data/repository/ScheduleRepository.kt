package com.radiocuxhaven.app.data.repository

import com.radiocuxhaven.app.data.model.ScheduleItem
import com.radiocuxhaven.app.data.model.ScheduleResponse
import com.radiocuxhaven.app.util.Constants
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.jsonArray
import okhttp3.OkHttpClient
import okhttp3.Request

class ScheduleRepository(private val httpClient: OkHttpClient) {

    private val json = Json {
        ignoreUnknownKeys = true
        isLenient = true
        coerceInputValues = true
    }

    /**
     * Lädt Sendeplan. Akzeptiert sowohl ein nacktes Array als auch
     * ein { "items": [...] } Objekt vom Backend.
     */
    suspend fun fetchSchedule(): Result<List<ScheduleItem>> = withContext(Dispatchers.IO) {
        runCatching {
            val request = Request.Builder()
                .url(Constants.SCHEDULE_URL)
                .get()
                .build()

            httpClient.newCall(request).execute().use { response ->
                if (!response.isSuccessful) {
                    error("HTTP ${response.code}")
                }
                val body = response.body?.string().orEmpty()
                if (body.isBlank()) return@use emptyList<ScheduleItem>()

                val element = json.parseToJsonElement(body)
                when (element) {
                    is JsonArray -> json.decodeFromJsonElement(
                        kotlinx.serialization.builtins.ListSerializer(ScheduleItem.serializer()),
                        element
                    )
                    is JsonObject -> {
                        if (element["items"] is JsonArray) {
                            json.decodeFromJsonElement(
                                ScheduleResponse.serializer(),
                                element
                            ).items
                        } else {
                            emptyList()
                        }
                    }
                    else -> emptyList()
                }
            }
        }
    }
}
